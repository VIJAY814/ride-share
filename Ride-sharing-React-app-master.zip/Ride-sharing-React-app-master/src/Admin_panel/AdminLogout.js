import React from "react";

const UserLogout = () => {
  return (
    <div className="col-md-9 userProfile-main">
      <div className="container">
        <h2>Admin Logout...</h2>
      </div>
    </div>
  );
};

export default UserLogout;
