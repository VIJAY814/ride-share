import React from "react";
import AdminPanel from "../../Admin_panel/AdminPanel";
import "../../user_interface/userInterface.css";

const AdminDashboardPage = () => {
  return <AdminPanel />;
};

export default AdminDashboardPage;
