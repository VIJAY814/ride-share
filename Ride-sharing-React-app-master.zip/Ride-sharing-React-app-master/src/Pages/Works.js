import React from 'react';
import Navbar from '../components/Header/Navbar';
import Footer from '../components/footer/Footer';

const Works = () => {
  return (
    <div>
      <Navbar />
      <Footer />
    </div>
  );
};

export default Works;
