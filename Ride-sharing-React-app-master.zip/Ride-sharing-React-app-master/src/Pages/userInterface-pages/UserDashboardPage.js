import React from "react";
import "../../user_interface/userInterface.css";
import UserInterface from "../../user_interface/UserInterface";

const UserDashboardPage = () => {
  return <UserInterface />;
};

export default UserDashboardPage;
