import React from 'react';
import Header from '../components/Header/Header';
import Navbar from '../components/Header/Navbar';
import Footer from '../components/footer/Footer';

const SearchRide = () => {
  return (
    <div>
      <Navbar />
      <Header />
      <Footer />
    </div>
  );
};

export default SearchRide;
