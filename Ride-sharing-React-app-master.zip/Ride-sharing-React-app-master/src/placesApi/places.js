const places = [
  {
    id: 1,
    location: "Select a location",
  },
  {
    id: 2,
    location: "Peshawar",
  },
  {
    id: 3,
    location: "Islamabad",
  },
  {
    id: 4,
    location: "Lahore",
  },
  {
    id: 5,
    location: "Abbottabad",
  },
  {
    id: 6,
    location: "Battagram",
  },
];

export default places;
