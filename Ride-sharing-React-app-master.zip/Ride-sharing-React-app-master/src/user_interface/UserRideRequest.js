import React from "react";
import HeaderRideSearch from "../components/Header/HeaderRideSearch";

const UserRideRequest = () => {
  return (
    <div className="col-md-9 userProfile-main">
      <div className="container">
        <HeaderRideSearch />
      </div>
    </div>
  );
};

export default UserRideRequest;
