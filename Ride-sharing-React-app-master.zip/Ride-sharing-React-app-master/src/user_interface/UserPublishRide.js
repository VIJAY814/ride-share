import React from "react";
import PublishRideFormCard from "../components/publish_Ride/PulishRideFormCard";

const UserPublishRide = () => {
  return (
    <div className="col-md-9 userProfile-main">
      <div className="container">
        <PublishRideFormCard />
      </div>
    </div>
  );
};

export default UserPublishRide;
